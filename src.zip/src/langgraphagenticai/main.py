import streamlit as st

from src.langgraphagenticai.ui.streamlitui.loadui import LoadStreamlitUI
from src.langgraphagenticai.LLMS.groqllm import GroqLLM
from src.langgraphagenticai.graph.graph_builder import GraphBuilder
from src.langgraphagenticai.ui.streamlitui.display_result import DisplayResultStreamlit


def load_langgraph_agenticai_app():
    """
    Entry point for LangGraph Agentic AI Streamlit App
    """

    # ---------------- LOAD UI ----------------
    ui = LoadStreamlitUI()
    user_input = ui.load_streamlit_ui()

    if not user_input:
        st.error("Failed to load UI inputs.")
        return

    # ---------------- USER MESSAGE ----------------
    user_message = None

    # AI News flow
    if st.session_state.get("IsFetchButtonClicked", False):
        user_message = st.session_state.get("timeframe")
        st.session_state.IsFetchButtonClicked = False

    # Chat-based flow
    else:
        user_message = st.chat_input(
            "Ask anything…"
        )

    # ---------------- MODEL & GRAPH SETUP ----------------
    try:
        llm_config = GroqLLM(user_contols_input=user_input)
        model = llm_config.get_llm_model()

        if not model:
            st.error("LLM initialization failed.")
            return

        usecase = user_input.get("selected_usecase")
        if not usecase:
            st.error("No use case selected.")
            return

        graph_builder = GraphBuilder(model)
        graph = graph_builder.setup_graph(usecase)

    except Exception as e:
        st.error(f"Setup failed: {e}")
        return

    # ---------------- RENDER OUTPUT ----------------
    DisplayResultStreamlit(
        usecase=usecase,
        graph=graph,
        user_message=user_message
    ).display_result_on_ui()


# ---------------- STREAMLIT ENTRY ----------------
if __name__ == "__main__":
    load_langgraph_agenticai_app()
