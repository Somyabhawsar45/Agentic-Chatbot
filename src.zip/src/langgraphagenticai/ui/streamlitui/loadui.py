import streamlit as st
import os
from src.langgraphagenticai.ui.uiconfigfile import Config


class LoadStreamlitUI:
    def __init__(self):
        self.config = Config()
        self.user_controls = {}

    def load_streamlit_ui(self):
        # ---------------- PAGE CONFIG ----------------
        st.set_page_config(
            page_title="Agentic AI Chatbot",
            page_icon="🤖",
            layout="wide"
        )

        # ---------------- SESSION DEFAULTS ----------------
        if "timeframe" not in st.session_state:
            st.session_state.timeframe = ""
        if "IsFetchButtonClicked" not in st.session_state:
            st.session_state.IsFetchButtonClicked = False

        # ---------------- GLOBAL CSS ----------------
        st.markdown("""
        <style>
            section[data-testid="stSidebar"] {
                background-color: #020617;
                border-right: 1px solid #1f2937;
            }

            .stSelectbox label,
            .stTextInput label {
                color: #e5e7eb;
                font-weight: 500;
            }

            .reset-btn button {
                background-color: #020617;
                color: #e5e7eb;
                border: 1px solid #1f2937;
                border-radius: 8px;
            }

            .reset-btn button:hover {
                border-color: #374151;
            }

            .block-container {
                padding-top: 2rem;
            }
        </style>
        """, unsafe_allow_html=True)

        # ---------------- HEADER ----------------
        st.markdown(
            f"""
            <div style="text-align:center; margin-bottom: 1.2rem;">
                <h1>🤖 {self.config.get_page_title()}</h1>
                <p style="color:#9ca3af; font-size:15px;">
                    Stateful Agentic AI Chat Interface
                </p>
            </div>
            """,
            unsafe_allow_html=True
        )

        # ---------------- SIDEBAR ----------------
        with st.sidebar:

            # Reset chat button
            st.markdown('<div class="reset-btn">', unsafe_allow_html=True)
            if st.button("♻️ Clear chat"):
                st.session_state.chat_history = []
                st.rerun()
            st.markdown('</div>', unsafe_allow_html=True)

            st.markdown("---")

            # LLM & Usecase options
            llm_options = self.config.get_llm_options()
            usecase_options = self.config.get_usecase_options()

            self.user_controls["selected_llm"] = st.selectbox(
                "🧠 LLM",
                llm_options
            )

            # ---------------- GROQ ----------------
            if self.user_controls["selected_llm"] == "Groq":
                self.user_controls["selected_groq_model"] = st.selectbox(
                    "⚡ Model",
                    self.config.get_groq_model_options()
                )

                self.user_controls["GROQ_API_KEY"] = st.session_state["GROQ_API_KEY"] = st.text_input(
                    "🔑 Groq API Key",
                    type="password"
                )

                if not self.user_controls["GROQ_API_KEY"]:
                    st.warning("Enter your Groq API key to continue")

            # ---------------- USECASE ----------------
            self.user_controls["selected_usecase"] = st.selectbox(
                "🧩 Use Case",
                usecase_options
            )

            # ---------------- TAVILY (Web + News) ----------------
            if self.user_controls["selected_usecase"] in ["Chatbot With Web", "AI News"]:
                self.user_controls["TAVILY_API_KEY"] = st.session_state["TAVILY_API_KEY"] = st.text_input(
                    "🌐 Tavily API Key",
                    type="password"
                )
                os.environ["TAVILY_API_KEY"] = self.user_controls["TAVILY_API_KEY"]

                if not self.user_controls["TAVILY_API_KEY"]:
                    st.warning("Enter your Tavily API key to continue")

            # ---------------- AI NEWS CONTROLS ----------------
            if self.user_controls["selected_usecase"] == "AI News":
                st.markdown("### 📰 AI News Explorer")

                time_frame = st.selectbox(
                    "📅 Time Frame",
                    ["Daily", "Weekly", "Monthly"],
                    index=0
                )

                if st.button("🔍 Fetch Latest AI News", use_container_width=True):
                    st.session_state.IsFetchButtonClicked = True
                    st.session_state.timeframe = time_frame

        return self.user_controls
