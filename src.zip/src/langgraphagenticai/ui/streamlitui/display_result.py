import streamlit as st
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage
import json


class DisplayResultStreamlit:
    def __init__(self, usecase, graph, user_message):
        self.usecase = usecase
        self.graph = graph
        self.user_message = user_message

        # ---------------- SESSION MEMORY ----------------
        if "chat_history" not in st.session_state:
            st.session_state.chat_history = []

    def display_result_on_ui(self):

        # ---------------- EMPTY STATE + CAPABILITIES ----------------
        if len(st.session_state.chat_history) == 0 and not self.user_message:
            st.markdown(
                """
                <div style="text-align:center; margin-top:8rem;">
                    <h2 style="font-weight:600;">What can I help with?</h2>
                    <p style="color:#9ca3af; margin-top:1rem; line-height:1.6;">
                        • 🌐 Web search with Tavily<br>
                        • 🧠 Stateful memory using LangGraph<br>
                        • 🧩 Tool-augmented reasoning<br>
                        • ⚡ Fast inference via Groq
                    </p>
                </div>
                """,
                unsafe_allow_html=True
            )
            return

        # ---------------- CHAT HISTORY ----------------
        for role, message in st.session_state.chat_history:
            avatar = "👤" if role == "user" else "🤖"
            with st.chat_message(role):
                st.markdown(f"{avatar} {message}")

        # ================= BASIC CHATBOT =================
        if self.usecase == "Basic Chatbot":

            if not self.user_message:
                return

            # ---- USER MESSAGE ----
            st.chat_message("user").markdown(f"👤 {self.user_message}")
            st.session_state.chat_history.append(("user", self.user_message))

            # ---- AGENT STATUS ----
            status = st.empty()
            status.info("🧠 Agent is thinking...")

            assistant_msg = st.chat_message("assistant")
            response_container = assistant_msg.empty()

            final_response = ""

            # ---- STREAM RESPONSE ----
            for event in self.graph.stream(
                {"messages": ("user", self.user_message)}
            ):
                for value in event.values():
                    msg = value.get("messages")
                    if isinstance(msg, AIMessage) and msg.content:
                        final_response += msg.content
                        response_container.markdown(f"🤖 {final_response}▌")

            response_container.markdown(f"🤖 {final_response}")
            status.success("✅ Done")

            st.session_state.chat_history.append(
                ("assistant", final_response)
            )

        # ================= CHATBOT WITH WEB =================
        elif self.usecase == "Chatbot With Web":

            if not self.user_message:
                return

            # ---- USER MESSAGE ----
            st.chat_message("user").markdown(f"👤 {self.user_message}")
            st.session_state.chat_history.append(("user", self.user_message))

            status = st.empty()
            status.warning("🔧 Agent is using web tools...")

            result = self.graph.invoke(
                {"messages": [HumanMessage(content=self.user_message)]}
            )

            # ---- EXECUTION TRACE ----
            with st.expander("🧩 Agent Execution Trace"):
                st.write("LLM → Groq")
                st.write("Tool → Tavily Web Search")

            # ---- PROCESS MESSAGES ----
            for msg in result["messages"]:

                # TOOL OUTPUT
                if isinstance(msg, ToolMessage):
                    with st.chat_message("assistant"):
                        st.markdown("### 🌐 Web Search Results")

                        try:
                            results = json.loads(msg.content)
                            for r in results[:5]:
                                st.markdown(
                                    f"""
                                    <div style="
                                        background:#020617;
                                        border:1px solid #1f2937;
                                        border-radius:12px;
                                        padding:14px;
                                        margin-bottom:12px;">
                                        <a href="{r.get('url')}" target="_blank">
                                            <b>{r.get('title')}</b>
                                        </a>
                                        <p style="color:#9ca3af; font-size:14px;">
                                            {r.get('content','')[:220]}...
                                        </p>
                                    </div>
                                    """,
                                    unsafe_allow_html=True
                                )
                        except Exception:
                            st.code(msg.content)

                # FINAL AI RESPONSE
                elif isinstance(msg, AIMessage) and msg.content:
                    with st.chat_message("assistant"):
                        st.markdown("### 🧠 AI Summary")
                        st.markdown(msg.content)

                    st.session_state.chat_history.append(
                        ("assistant", msg.content)
                    )

            status.success("✅ Done")

        # ================= AI NEWS =================
        elif self.usecase == "AI News":

            if not self.user_message:
                return

            status = st.empty()
            status.warning("📰 Fetching AI news...")

            self.graph.invoke(
                {"messages": HumanMessage(content=self.user_message)}
            )

            with st.expander("🧩 Agent Execution Trace"):
                st.write("Tool → Tavily")
                st.write("LLM → Groq")

            try:
                path = f"./AINews/{self.user_message.lower()}_summary.md"
                with open(path, "r") as f:
                    content = f.read()

                st.markdown(content, unsafe_allow_html=True)
                st.session_state.chat_history.append(
                    ("assistant", content)
                )
                status.success("✅ Done")

            except Exception as e:
                st.error(str(e))
